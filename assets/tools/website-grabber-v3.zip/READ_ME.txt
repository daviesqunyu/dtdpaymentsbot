﻿DTD TOOLS - placeholder file.

This is a sample/placeholder download for: website-grabber-v3
Replace this zip in assets/tools/ with your real software to activate delivery.
