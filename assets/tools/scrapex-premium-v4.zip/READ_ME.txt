﻿DTD TOOLS - placeholder file.

This is a sample/placeholder download for: scrapex-premium-v4
Replace this zip in assets/tools/ with your real software to activate delivery.
