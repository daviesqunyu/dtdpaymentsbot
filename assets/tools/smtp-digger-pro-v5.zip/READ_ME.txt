﻿DTD TOOLS - placeholder file.

This is a sample/placeholder download for: smtp-digger-pro-v5
Replace this zip in assets/tools/ with your real software to activate delivery.
