﻿DTD TOOLS - placeholder file.

This is a sample/placeholder download for: dtd-sender-suite-v2
Replace this zip in assets/tools/ with your real software to activate delivery.
